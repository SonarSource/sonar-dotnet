﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Example.Core
{
    class Dummy
    {
        public void FooBar()
        {
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
            Console.WriteLine("hello, this meethod will not be covered by any test");
        }
    }
}
